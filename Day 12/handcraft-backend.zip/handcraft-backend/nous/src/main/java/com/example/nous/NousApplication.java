package com.example.nous;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class
NousApplication {

	public static void main(String[] args) {
		SpringApplication.run(NousApplication.class, args);
	}

}
