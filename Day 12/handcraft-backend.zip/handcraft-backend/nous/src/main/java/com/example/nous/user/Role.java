package com.example.nous.user;

import lombok.RequiredArgsConstructor;





@RequiredArgsConstructor
public enum Role {

  USER,
  ADMIN
}